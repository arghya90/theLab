
void * rt_rtvi_init(int xsize, int ysize);
void rt_rtvi_clear(void * voidhandle);
void rt_rtvi_displayimage(unsigned char * img, void * voidhandle);

