
double jsval(double, double, double);


