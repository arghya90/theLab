/*
 * global.h - any/all global data items etc should be in this file
 *
 *  $Id: global.h,v 1.15 1998/08/08 20:08:09 johns Exp $
 *
 */

extern int parinitted;

