/* 
 * machine.h - This is the machine specific include file
 *
 *  $Id: machine.h,v 1.23 1998/07/13 17:54:54 johns Exp $
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

