# LaTeX2HTML 2002-2-1 (1.70)
# Associate images original text with physical files.


$key = q/#;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="$\char93 $">|; 

$key = q/{displaymath}frac{1}{K_c+K_ld+k_qd^2}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="126" HEIGHT="47" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="\begin{displaymath}
\frac {1} {K_c + K_l d + k_q d^2}
\end{displaymath}">|; 

$key = q/###;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="48" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="$\char93 \char93 \char93 $">|; 

1;

