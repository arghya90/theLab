# LaTeX2HTML 2002-2-1 (1.70)
# Associate internals original text with physical files.


$key = q/eq:attenuation/;
$ref_files{$key} = "$dir".q|node16.html|; 
$noresave{$key} = "$nosave";

$key = q/index:label/;
$ref_files{$key} = "$dir".q|node19.html|; 
$noresave{$key} = "$nosave";

1;

